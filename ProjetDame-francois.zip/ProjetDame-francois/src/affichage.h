void afficherJoueur(int joueurActuel);
void afficheDamier(Damier damier[10][10]);
void afficheCoup(int * tabCoup[2], int nombreCoup);
