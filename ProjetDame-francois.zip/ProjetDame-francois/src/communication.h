
// #include "deplacement.h"



char **read_move_query(char * buffer);
