
int unePartie ();
int unTour(Damier damier[10][10], int joueurActuel);
int lireCoordonnees(void);
int jeuEstFini(Damier damier[10][10], int joueurActuel);
void initialiseDamier(Damier damier[10][10]);
