#include <stdio.h>
#include <stdlib.h>
#include <SDL2/SDL.h>
#include "main.h"
#include "affichage.h"
#include "deplacement.h"
#include "partie.h"

int main(void)
{
	unePartie();
}
