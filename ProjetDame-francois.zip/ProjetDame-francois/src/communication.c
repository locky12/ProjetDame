
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include "communication.h"
//#include "sdl2.h"



// int main(int argc, char const *argv[]) {
// Move * move = malloc(sizeof(Move));
// int ** arrayCapture = malloc(10 *sizeof(arrayCapture));
// for (int i = 0; i< 10; i++){
//   arrayCapture[i] = malloc(2 * sizeof(arrayCapture));
// }
// char ** result;
// char  buffer [100];
// arrayCapture[0][0] = 4;
// arrayCapture[0][1] = 5;
// arrayCapture[1][0] = 1;
// arrayCapture[1][1] = 3;
// move->position[0] = 9 ;
// move->position[0] = 2;
// move->newPosition[0] = 8 ;
// move->newPosition[1] = 7;
// // int ** arrayCapture = malloc(10 * sizeof(arrayCapture));
// send_move (move, arrayCapture,2,buffer);
// result = read_move_query (buffer);
// printf("%s\n",buffer );
// printf("%c\n",result[0][0] );
// printf("%c\n",result[0][1] );
// printf("%c\n",result[1][0] );
// printf("%c\n",result[1][1] );
// printf("%c\n",result[2][0] );
// printf("%c\n",result[2][1] );
//   return 0;
// }
